"use client";
import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import DeadlineBanner from './components/DeadlineBanner';
import Navbar from './components/Navbar';
import { useRouter } from 'next/navigation';

interface BetData {
  match_name: string;
  bet_type: string;
  domestic_odds: number;
  pinnacle_odds: number;
  true_probability: number;
  expected_value: number;
  kelly_pct: number;
  max_tax_free_stake?: number;
  timestamp: string;
}

export default function Home() {
  const [bets, setBets] = useState<BetData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const router = useRouter();

  const fetchBets = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/bets');
      if (!res.ok) throw new Error('Failed to fetch data');
      const data = await res.json();
      setBets(data);
    } catch (err) {
      setError('데이터를 불러오는데 실패했습니다.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBets();
  }, []);

  // Helper to highlight value
  const getValueColor = (ev: number) => {
    if (ev >= 1.10) return 'text-red-600 font-bold';
    if (ev >= 1.05) return 'text-blue-600 font-bold';
    return 'text-gray-900';
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col font-sans">
      {/* Top Banner */}
      <div className="sticky top-0 z-50 bg-white shadow-sm border-b border-gray-300">
        <DeadlineBanner />
        <Navbar />
      </div>

      {/* Main Content */}
      <main className="flex-grow max-w-7xl mx-auto px-2 sm:px-6 lg:px-8 py-6 w-full pb-32">

        {/* Header Section */}
        <div className="flex justify-between items-end mb-4 border-b-2 border-gray-400 pb-2">
          <div>
            <h2 className="text-lg font-bold text-gray-800 flex items-center">
              <span className="w-2 h-6 bg-indigo-600 mr-2 rounded-sm"></span>
              실시간 추천 경기
            </h2>
            <p className="text-xs text-gray-500 mt-1 ml-4">해외 배당 흐름을 분석하여 지금 구매해야 할 경기를 엄선했습니다.</p>
          </div>
          <button
            onClick={fetchBets}
            className="px-3 py-1 bg-white border border-gray-300 text-xs text-gray-700 rounded hover:bg-gray-50 flex items-center shadow-sm"
          >
            {loading ? '검색 중...' : '🔄 새로고침'}
          </button>
        </div>

        {error && (
          <div className="bg-red-50 text-red-700 p-3 rounded text-sm mb-4 border border-red-200">
            {error}
          </div>
        )}

        {/* Betman Style Table */}
        <div className="bg-white border border-gray-300 shadow-sm overflow-hidden">
          <table className="w-full text-sm text-left">
            <thead className="bg-gray-100 text-gray-700 border-b border-gray-300 font-bold">
              <tr>
                <th className="py-3 px-4 w-16 text-center">번호</th>
                <th className="py-3 px-4 w-32">경기일시/리그</th>
                <th className="py-3 px-4 text-center">승 (홈)</th>
                <th className="py-3 px-4 text-center">무</th>
                <th className="py-3 px-4 text-center">패 (원정)</th>
                <th className="py-3 px-4 text-center w-24">추천 픽</th>
                <th className="py-3 px-4 text-center w-24">기대수익</th>
                <th className="py-3 px-4 text-center w-20">분석</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {loading && bets.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-10 text-center text-gray-500">
                    데이터를 분석하고 있습니다...
                  </td>
                </tr>
              ) : bets.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-10 text-center text-gray-500">
                    현재 추천 가능한 경기가 없습니다.
                  </td>
                </tr>
              ) : (
                bets.map((bet, idx) => {
                  const matchDate = new Date(bet.timestamp).toLocaleDateString('ko-KR', { month: 'numeric', day: 'numeric' });
                  const matchTime = new Date(bet.timestamp).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' });
                  const evPercent = ((bet.expected_value - 1) * 100).toFixed(1);

                  return (
                    <tr key={idx} className="hover:bg-indigo-50 transition cursor-pointer group" onClick={() => router.push(`/bets/${idx}`)}>
                      <td className="py-3 px-4 text-center font-bold text-gray-400">{idx + 101}</td>
                      <td className="py-3 px-4">
                        <div className="font-bold text-gray-800">{bet.match_name.split('vs')[0]}</div>
                        <div className="text-xs text-gray-500 mt-0.5">vs {bet.match_name.split('vs')[1]}</div>
                        <div className="text-[10px] text-gray-400 mt-1">{matchDate} {matchTime}</div>
                      </td>

                      {/* Odds Display - Simple Logic for highlight */}
                      <td className={`py-3 px-4 text-center border-l bg-gray-50 ${bet.bet_type === 'Home' ? 'bg-indigo-100 text-indigo-700 font-bold ring-2 ring-indigo-500 ring-inset' : ''}`}>
                        <div className="text-gray-900">{bet.domestic_odds}</div>
                      </td>
                      <td className={`py-3 px-4 text-center border-l bg-gray-50 ${bet.bet_type === 'Draw' ? 'bg-indigo-100 text-indigo-700 font-bold ring-2 ring-indigo-500 ring-inset' : ''}`}>
                        <div className="text-gray-400">-</div> {/* Mock doesn't carry draw odds in root obj, simplified */}
                      </td>
                      <td className={`py-3 px-4 text-center border-l bg-gray-50 ${bet.bet_type === 'Away' ? 'bg-indigo-100 text-indigo-700 font-bold ring-2 ring-indigo-500 ring-inset' : ''}`}>
                        <div className="text-gray-900">{/* Mock logic needed for full odds */} - </div>
                      </td>

                      <td className="py-3 px-4 text-center border-l">
                        <span className="inline-block px-2 py-1 rounded bg-red-100 text-red-700 text-xs font-bold">
                          {bet.bet_type === 'Home' ? '홈승' : bet.bet_type === 'Draw' ? '무승부' : '원정승'}
                        </span>
                      </td>
                      <td className={`py-3 px-4 text-center font-bold ${getValueColor(bet.expected_value)}`}>
                        {evPercent}%
                      </td>
                      <td className="py-3 px-4 text-center">
                        <button className="text-gray-400 hover:text-indigo-600 group-hover:text-indigo-600">
                          🔍
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
          <div className="p-3 bg-gray-50 border-t border-gray-200 text-xs text-right text-gray-500">
            * 붉은색 숫자는 기대수익률 10% 이상, 파란색은 5% 이상을 의미합니다.
          </div>
        </div>
      </main>
    </div>
  );
}
