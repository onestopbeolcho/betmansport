from fastapi import FastAPI
import os
from dotenv import load_dotenv

# Force load .env from project root
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
env_path = os.path.join(BASE_DIR, ".env")
loaded = load_dotenv(env_path)
print(f"DEBUG_ENV: Path={env_path}, Loaded={loaded}, KeyPresent={bool(os.getenv('PINNACLE_API_KEY'))}")
from app.api.endpoints import admin, odds, auth, payments, portfolio, market
from fastapi.middleware.cors import CORSMiddleware
from app.db.base import Base
from app.db.session import engine
# Import models to register them with Base.metadata
import app.models.bets_db
import app.models.config_db
import app.models.user_db # Register User Models

app = FastAPI(title="Smart Proto Investor API")

# CORS Setup (Allow Frontend to connect)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include Routers
app.include_router(admin.router, prefix="/api/admin", tags=["admin"])
app.include_router(odds.router, prefix="/api", tags=["odds"])
app.include_router(auth.router, prefix="/api/auth", tags=["auth"])
app.include_router(payments.router, prefix="/api/payments", tags=["payments"])
app.include_router(portfolio.router, prefix="/api/portfolio", tags=["portfolio"])
app.include_router(market.router, prefix="/api/market", tags=["market"])

@app.on_event("startup")
async def startup_event():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

@app.get("/")
def read_root():
    return {"message": "Welcome to Smart Proto Investor API"}
