# List of direct scraping URLs provided by admin
SCRAPING_URLS = [
    "https://www.betman.co.kr/main/mainPage/gamebuy/gameSlip.do?frameType=typeA&gmId=G101&gmTs=260014"
]
