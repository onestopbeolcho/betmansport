from typing import List, Optional
import httpx
from bs4 import BeautifulSoup
from datetime import datetime, timezone
import json
import traceback
import logging

from app.services.base_provider import BaseOddsProvider
from app.schemas.odds import OddsItem

# Configure logger
logger = logging.getLogger(__name__)

class BetmanCrawler(BaseOddsProvider):
    def __init__(self):
        super().__init__("Betman")
        self.base_url = "https://www.betman.co.kr"

    def fetch_odds(self) -> List[OddsItem]:
        """
        Main entry point.
        Attempts to fetch real data. If blocked/fails, returns Mock data.
        """
        try:
            real_data = self._fetch_real_data()
            if real_data and len(real_data) > 0:
                logger.info(f"Successfully fetched {len(real_data)} items from Betman.")
                print(f"✅ Betman: Fetched {len(real_data)} real items.")
                return real_data
            else:
                logger.warning("No real data fetched from Betman.")
                print("⚠️ Betman: No real data fetched. Falling back to Mock?")
                return self._get_mock_data()
        except Exception as e:
            logger.error(f"Error in fetch_odds: {e}")
            traceback.print_exc()
            return self._get_mock_data()

    def _fetch_real_data(self) -> List[OddsItem]:
        # 1. Discover Active Round (gmTs)
        gm_ts, gm_id = self._discover_round_id()
        if not gm_ts:
            return []

        # 2. Fetch Odds Page
        data = self._fetch_odds_page(gm_id, gm_ts)
        if not data:
            return []

        # 3. Parse Data
        return self._parse_html(data)

    def _discover_round_id(self) -> (Optional[str], Optional[str]):
        """
        Attempts to find the active round ID (gmTs) for Proto Match (G101).
        """
        api_url = f"{self.base_url}/buyPsblGame/inqBuyAbleGameInfoList.do"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Accept": "application/json, text/javascript, */*; q=0.01",
            "Referer": f"{self.base_url}/main/mainPage/gamebuy/buyableGameList.do",
            "Origin": self.base_url,
            "X-Requested-With": "XMLHttpRequest",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "Host": "www.betman.co.kr",
            "Connection": "keep-alive"
        }
        
        try:
            # Use sync Client
            with httpx.Client(verify=False, timeout=10.0) as client:
                resp = client.post(api_url, headers=headers, data={})
                if resp.status_code != 200:
                    logger.error(f"API Error: {resp.status_code}")
                    return None, None
                
                # Check for HTML response (WAF Block)
                if "text/html" in resp.headers.get("content-type", ""):
                    logger.error("API Blocked (Received HTML)")
                    with open("blocked_response.html", "w", encoding="utf-8") as f:
                        f.write(resp.text)
                    return None, None
                
                data = resp.json()
                # Find G101
                if "protoGames" in data:
                    for game in data.get("protoGames", []):
                        if game.get("gmId") == "G101":
                            return game.get("gmTs"), "G101"
                            
                # Fallback to first available
                if data.get("protoGames"):
                    g = data["protoGames"][0]
                    return g.get("gmTs"), g.get("gmId")
                    
        except Exception as e:
            logger.error(f"Discovery Error: {e}")
            
        return None, None

    def _fetch_odds_page(self, gm_id: str, gm_ts: str) -> Optional[dict]:
        """
        Fetches the game data JSON from gameInfoInq.do.
        """
        target_url = f"{self.base_url}/buyPsblGame/gameInfoInq.do"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Referer": f"{self.base_url}/main/mainPage/gamebuy/buyableGameList.do",
            "Accept": "application/json, text/javascript, */*; q=0.01",
            "Host": "www.betman.co.kr",
            "Origin": self.base_url,
            "X-Requested-With": "XMLHttpRequest",
            "Content-Type": "application/json; charset=UTF-8",
            "Connection": "keep-alive"
        }
        
        payload = {
            "gmId": gm_id,
            "gmTs": gm_ts,
            "gameYear": "",
            "_sbmInfo": {"debugMode": "false"}
        }

        try:
            with httpx.Client(verify=False, timeout=15.0) as client:
                resp = client.post(target_url, headers=headers, json=payload)
                if resp.status_code == 200:
                    try:
                        return resp.json()
                    except json.JSONDecodeError:
                        logger.error("Failed to decode JSON response")
                        # Debug: Save if HTML
                        with open("debug_betman_error.html", "w", encoding="utf-8") as f:
                            f.write(resp.text)
                else:
                    logger.error(f"API Error: {resp.status_code}")
        except Exception as e:
            logger.error(f"Fetch Page Error: {e}")
        return None

    def _parse_html(self, data: dict) -> List[OddsItem]:
        """
        Parses the JSON data from gameInfoInq.do (formerly _parse_html).
        """
        odds_items = []
        if not data or "compSchedules" not in data:
            logger.warning("No compSchedules in data")
            return []

        try:
            keys = data["compSchedules"]["keys"]
            datas = data["compSchedules"]["datas"]
            
            # Map keys to indices for faster access
            idx_map = {k: i for i, k in enumerate(keys)}
            
            # Required fields
            key_match_seq = idx_map.get("matchSeq")
            key_sport = idx_map.get("itemCode") # SC, BS, BK, VL
            key_league = idx_map.get("leagueName")
            key_home = idx_map.get("homeName")
            key_away = idx_map.get("awayName")
            key_date = idx_map.get("gameDate")
            key_win = idx_map.get("winAllot")
            key_draw = idx_map.get("drawAllot")
            key_lose = idx_map.get("loseAllot")
            key_handi = idx_map.get("handi")
            key_status = idx_map.get("protoStatus") # '2' = SaleProgress

            sport_map = {
                "SC": "Soccer", "BS": "Baseball", "BK": "Basketball", "VL": "Volleyball"
            }

            for row in datas:
                # Filter for Active Status (2) and Standard Game (handi == 0, 15, 16)
                # 0: Normal, 15: Normal?, 16: Normal? (Based on game_slip.js)
                handi = row[key_handi]
                status = row[key_status]
                
                if str(status) != '2':
                    continue
                if handi not in [0, 15, 16]:
                    continue

                try:
                    match_time_ms = row[key_date]
                    match_time = datetime.fromtimestamp(match_time_ms / 1000.0, timezone.utc).isoformat()
                    
                    item = OddsItem(
                        provider=self.provider_name,
                        sport=sport_map.get(row[key_sport], "Unknown"),
                        league=row[key_league],
                        team_home=row[key_home],
                        team_away=row[key_away],
                        home_odds=float(row[key_win]) if row[key_win] else 0.0,
                        draw_odds=float(row[key_draw]) if row[key_draw] else 0.0,
                        away_odds=float(row[key_lose]) if row[key_lose] else 0.0,
                        match_time=match_time
                    )
                    odds_items.append(item)
                except Exception as ex:
                    logger.warning(f"Error parsing row: {ex}")
                    continue

        except Exception as e:
            logger.error(f"Parse Error: {e}")
            
        return odds_items

    def _get_mock_data(self) -> List[OddsItem]:
        return [
            OddsItem(
                provider=self.provider_name,
                sport="Soccer",
                league="EPL",
                team_home="맨체스터 시티", # Korean Name Required
                team_away="리버풀",
                home_odds=2.50,  # Betman Higher (Value!) vs Pinn 1.80
                draw_odds=3.30,
                away_odds=3.40,
                match_time="2026-02-10T19:00:00Z"
            ),
            OddsItem(
                provider=self.provider_name,
                sport="Soccer",
                league="La Liga",
                team_home="레알 마드리드",
                team_away="바르셀로나",
                home_odds=2.30,  # Betman Higher vs Pinn 1.95 (EV High)
                draw_odds=3.40,
                away_odds=3.90,
                match_time="2026-02-11T19:00:00Z"
            )
        ]
