from fastapi import APIRouter, Depends
from typing import List
from app.services.pinnacle_api import pinnacle_service
from app.schemas.odds import OddsItem

router = APIRouter()

@router.get("/pinnacle", response_model=List[OddsItem])
async def get_all_pinnacle_odds():
    """
    Return all cached Pinnacle odds without filtering.
    """
    return pinnacle_service.fetch_odds()
