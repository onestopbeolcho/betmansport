from datetime import datetime
import logging
from typing import Optional, Dict

# Configure Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ResultGrader:
    """
    Grades betting portfolio items against actual game results.
    Handles sport-specific rules (Soccer 90m vs Others OT).
    """

    def __init__(self):
        pass

    def fetch_result(self, match_name: str, sport: str) -> Optional[Dict]:
        """
        Fetch result from External API (Mock for now, needs TheOddsAPI integration)
        TODO: Integrate with TheOddsAPI scores endpoint.
        """
        # Mock implementation for development
        logger.info(f"Fetching result for {match_name} ({sport})")
        return None

    def grade_bet(self, selection: str, result_score: Dict, sport: str) -> str:
        """
        Determines if the bet won or lost.
        Args:
            selection: User's pick (Home/Draw/Away)
            result_score: {'home_score': int, 'away_score': int, 'status': 'Finished'}
            sport: 'soccer', 'baseball', 'basketball'
        Returns:
            'WIN', 'LOSS', 'PUSH', 'PENDING'
        """
        if not result_score or result_score.get('status') != 'Finished':
            return 'PENDING'

        home_score = result_score['home_score']
        away_score = result_score['away_score']
        
        # Sport-Specific Logic
        if sport.lower() == 'soccer':
            # Soccer: 90m Result (Draw possible)
            if home_score > away_score: actual = 'Home'
            elif home_score < away_score: actual = 'Away'
            else: actual = 'Draw'
        else:
            # Baseball/Basketball: OT Included (No Draw usually, unless specific rule)
            # If External API returns OT score in final, we use it.
            if home_score > away_score: actual = 'Home'
            else: actual = 'Away'
            # Note: If API separates OT, we must sum them up for Baseball/Basketball.

        if selection == actual:
            return 'WIN'
        elif selection != actual:
            return 'LOSS'
        
        return 'PENDING'

result_grader = ResultGrader()
