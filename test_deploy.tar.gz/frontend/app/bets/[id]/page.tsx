"use client";

import React, { useEffect, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import Link from 'next/link';

// Reuse interface or import shared type
interface BetData {
    id?: number;
    match_name: string;
    bet_type: string;
    domestic_odds: number;
    pinnacle_odds: number;
    true_probability: number;
    expected_value: number;
    kelly_pct: number;
    max_tax_free_stake?: number;
    timestamp: string;
}

export default function BetDetail() {
    const params = useParams(); // { id: string }
    const [bet, setBet] = useState<BetData | null>(null);
    const [loading, setLoading] = useState(true);

    // In a real app, we would fetch /api/bets/{id}. 
    // For now, we fetch all and find by ID since the Mock might not support detail routing yet.
    // Or we assume the ID is the index for simplicity in this MVP phase if IDs aren't persistent.
    // Update: We allowed IDs in schema, so let's try to find by ID from the list.

    useEffect(() => {
        const fetchDetail = async () => {
            try {
                const res = await fetch('/api/bets');
                if (!res.ok) throw new Error('Fetch failed');
                const data: BetData[] = await res.json();

                // Find matching item. 
                // Note: The list ID is arbitrary in our Mock/DB hybrid.
                // If we clicked from list with ID=101+index, we need to handle that mapping.
                // Let's assume params.id corresponds to the index passed from list page.

                const index = Number(params.id);
                if (data[index]) {
                    setBet(data[index]);
                } else {
                    // Fallback: try finding by DB ID if available
                    const found = data.find(b => b.id === Number(params.id));
                    if (found) setBet(found);
                }
            } catch (e) {
                console.error(e);
            } finally {
                setLoading(false);
            }
        };

        if (params.id) {
            fetchDetail();
        }
    }, [params.id]);

    if (loading) return <div className="p-10 text-center">분석 데이터를 불러오는 중입니다...</div>;
    if (!bet) return <div className="p-10 text-center">해당 경기 분석을 찾을 수 없습니다.</div>;

    const evPercent = ((bet.expected_value - 1) * 100).toFixed(1);
    const winProb = (bet.true_probability * 100).toFixed(1);
    const kellyStake = (bet.kelly_pct * 100).toFixed(1);

    return (
        <div className="min-h-screen bg-gray-50 font-sans">
            {/* Navbar (Simplified) */}
            <div className="bg-white border-b border-gray-200 shadow-sm sticky top-0 z-10">
                <div className="max-w-3xl mx-auto px-4 h-14 flex items-center">
                    <Link href="/" className="text-gray-500 hover:text-gray-900 flex items-center text-sm font-medium">
                        ← 목록으로 돌아가기
                    </Link>
                    <div className="ml-auto font-bold text-indigo-800">SMART PROTO</div>
                </div>
            </div>

            <div className="max-w-3xl mx-auto px-4 py-8">

                {/* Match Header */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
                    <div className="flex justify-between items-center mb-4">
                        <span className="bg-indigo-100 text-indigo-800 text-xs font-bold px-2 py-1 rounded">축구</span>
                        <span className="text-gray-400 text-xs">{new Date(bet.timestamp).toLocaleString()}</span>
                    </div>
                    <h1 className="text-2xl font-bold text-gray-900 text-center mb-2">{bet.match_name}</h1>
                    <div className="flex justify-center items-center space-x-8 mt-4">
                        <div className="text-center">
                            <div className="text-sm text-gray-500">홈 (HOME)</div>
                            <div className="text-lg font-bold">
                                {bet.match_name.split('vs')[0]}
                            </div>
                        </div>
                        <div className="text-gray-300 font-light">VS</div>
                        <div className="text-center">
                            <div className="text-sm text-gray-500">원정 (AWAY)</div>
                            <div className="text-lg font-bold">
                                {bet.match_name.split('vs')[1]}
                            </div>
                        </div>
                    </div>
                </div>

                {/* Core Analysis Card */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
                    <h2 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
                        📊 AI 가치 분석 리포트
                    </h2>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

                        {/* Comparison Visual */}
                        <div className="bg-gray-50 p-4 rounded-lg">
                            <h3 className="text-sm font-bold text-gray-700 mb-3">배당률 비교 (Price Efficiency)</h3>
                            <div className="space-y-3">
                                <div className="flex justify-between items-center">
                                    <div className="text-xs text-gray-500">해외 (Pinnacle) True Odds</div>
                                    <div className="font-mono text-gray-600">{(1 / bet.true_probability).toFixed(2)}</div>
                                </div>
                                <div className="flex justify-between items-center">
                                    <div className="text-xs text-indigo-600 font-bold">국내 (Betman) Actual Odds</div>
                                    <div className="font-mono text-indigo-600 font-bold text-lg">{bet.domestic_odds}</div>
                                </div>
                                <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                                    <div className="bg-indigo-500 h-2 rounded-full" style={{ width: '100%' }}></div>
                                </div>
                                <p className="text-xs text-gray-500 mt-1">
                                    * 배트맨 배당이 해외 기준 적정 배당보다 <strong>{((bet.domestic_odds - (1 / bet.true_probability)) / (1 / bet.true_probability) * 100).toFixed(1)}%</strong> 더 높습니다.
                                </p>
                            </div>
                        </div>

                        {/* Key Metrics */}
                        <div className="space-y-4">
                            <div>
                                <div className="text-sm text-gray-500 mb-1">AI 승리 확률 예측</div>
                                <div className="text-3xl font-black text-gray-900">{winProb}%</div>
                            </div>
                            <div>
                                <div className="text-sm text-gray-500 mb-1">기대 수익률 (ROI)</div>
                                <div className={`text-2xl font-black ${bet.expected_value >= 1.05 ? 'text-blue-600' : 'text-gray-700'}`}>
                                    +{evPercent}%
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Recommendation Card */}
                <div className="bg-indigo-50 rounded-xl border border-indigo-100 p-6">
                    <h2 className="text-lg font-bold text-indigo-900 mb-4">💡 투자 가이드 (Money Management)</h2>
                    <div className="flex items-start space-x-4">
                        <div className="text-4xl">💰</div>
                        <div>
                            <h3 className="font-bold text-indigo-800 text-lg">
                                추천: {bet.bet_type === 'Home' ? '홈승' : bet.bet_type === 'Draw' ? '무승부' : '원정승'} 베팅
                            </h3>
                            <p className="text-indigo-700 text-sm mt-1">
                                이 기회는 수학적으로 <strong>{evPercent}%</strong>의 장기 수익이 기대됩니다.
                                자산의 안정을 위해 <strong>켈리 기준(Kelly Criterion)</strong>에 따라
                                보유 자금의 <strong>{kellyStake}%</strong> 만 투자하는 것을 권장합니다.
                            </p>
                            {bet.max_tax_free_stake && (
                                <div className="mt-3 bg-white bg-opacity-60 p-2 rounded text-xs text-indigo-800">
                                    🛑 비과세 한도: {bet.max_tax_free_stake.toLocaleString()}원 이하 베팅 권장
                                </div>
                            )}
                        </div>
                    </div>
                </div>

            </div>
        </div>
    );
}
