"use client";
import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

export default function Navbar() {
    const pathname = usePathname();

    const isActive = (path: string) =>
        pathname === path ? "text-indigo-600 border-b-2 border-indigo-600" : "hover:text-gray-900";

    return (
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-14 flex items-center justify-between">
            <div className="flex items-center space-x-6">
                <Link href="/" className="text-xl font-bold text-indigo-800 tracking-tight">SMART PROTO</Link>
                <div className="hidden md:flex space-x-4 text-sm font-medium text-gray-600 h-14 items-center">
                    <Link href="/" className={`px-1 h-full flex items-center ${isActive('/')}`}>가치투자</Link>
                    <Link href="/market" className={`px-1 h-full flex items-center ${isActive('/market')}`}>전체경기(Market)</Link>
                    <Link href="/manual" className={`px-1 h-full flex items-center ${isActive('/manual')}`}>이용가이드</Link>
                </div>
            </div>
            <div className="flex items-center space-x-3">
                <Link href="/pricing" className="px-4 py-1.5 rounded bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 transition">
                    구독하기
                </Link>
            </div>
        </nav>
    );
}
