"use client";
import React, { useEffect, useState } from 'react';
import DeadlineBanner from '../components/DeadlineBanner';
import Navbar from '../components/Navbar';

interface OddsItem {
    provider: string;
    team_home: string;
    team_away: string;
    home_odds: number;
    draw_odds: number;
    away_odds: number;
    match_time: string;
    sport: string;
    league: string;
}

export default function MarketPage() {
    const [odds, setOdds] = useState<OddsItem[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    const fetchOdds = async () => {
        setLoading(true);
        setError('');
        try {
            const res = await fetch('http://localhost:8000/api/market/pinnacle');
            if (!res.ok) throw new Error('Failed to fetch market data');
            const data = await res.json();
            setOdds(data);
        } catch (err) {
            setError('시장 데이터를 불러오는데 실패했습니다.');
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchOdds();
    }, []);

    const formatTime = (isoString: string) => {
        try {
            const date = new Date(isoString);
            return date.toLocaleString('ko-KR', {
                month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false
            });
        } catch {
            return isoString;
        }
    };

    return (
        <div className="min-h-screen bg-gray-100 flex flex-col font-sans">
            <div className="sticky top-0 z-50 bg-white shadow-sm border-b border-gray-300">
                <DeadlineBanner />
                <Navbar />
            </div>

            <main className="flex-grow max-w-7xl mx-auto px-2 sm:px-6 lg:px-8 py-6 w-full pb-32">
                <div className="flex justify-between items-end mb-4 border-b-2 border-indigo-600 pb-2">
                    <div>
                        <h2 className="text-xl font-bold text-gray-800 flex items-center">
                            <span className="w-2 h-6 bg-indigo-600 mr-2 rounded-sm"></span>
                            전체 경기 배당 (Pinnacle)
                        </h2>
                        <p className="text-sm text-gray-500 mt-1 ml-4">수집된 모든 해외 배당 정보를 보여줍니다.</p>
                    </div>
                    <button
                        onClick={fetchOdds}
                        className="px-3 py-1 bg-white border border-gray-300 text-xs text-gray-700 rounded hover:bg-gray-50 flex items-center shadow-sm"
                    >
                        {loading ? '로딩 중...' : '🔄 새로고침'}
                    </button>
                </div>

                {error && (
                    <div className="bg-red-50 text-red-700 p-3 rounded text-sm mb-4 border border-red-200">
                        {error}
                    </div>
                )}

                {/* Odds Table */}
                <div className="bg-white border border-gray-300 shadow-sm overflow-hidden rounded-lg">
                    <div className="overflow-x-auto">
                        <table className="min-w-full text-center text-sm">
                            <thead className="bg-gray-100 text-gray-600 uppercase text-xs font-semibold tracking-wider border-b border-gray-300">
                                <tr>
                                    <th className="py-3 px-2 w-24">시간/리그</th>
                                    <th className="py-3 px-4 text-right w-1/3">홈팀 (Home)</th>
                                    <th className="py-3 px-2 w-20">승</th>
                                    <th className="py-3 px-2 w-20">무</th>
                                    <th className="py-3 px-2 w-20">패</th>
                                    <th className="py-3 px-4 text-left w-1/3">원정팀 (Away)</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-200 bg-white">
                                {loading && odds.length === 0 ? (
                                    <tr><td colSpan={6} className="py-8 text-center text-gray-500">데이터를 불러오는 중입니다...</td></tr>
                                ) : odds.length === 0 ? (
                                    <tr><td colSpan={6} className="py-8 text-center text-gray-500">표시할 경기가 없습니다.</td></tr>
                                ) : (
                                    odds.map((item, idx) => (
                                        <tr key={idx} className="hover:bg-indigo-50 transition-colors duration-150">
                                            <td className="py-3 px-2 text-gray-500 text-xs text-center border-r border-gray-100">
                                                <div className="font-bold text-indigo-700">{item.league}</div>
                                                <div>{formatTime(item.match_time)}</div>
                                            </td>
                                            <td className="py-3 px-4 text-gray-800 font-medium text-right truncate">
                                                {item.team_home}
                                            </td>
                                            <td className="py-3 px-2 text-indigo-600 font-bold bg-gray-50">{item.home_odds.toFixed(2)}</td>
                                            <td className="py-3 px-2 text-gray-400">{item.draw_odds.toFixed(2)}</td>
                                            <td className="py-3 px-2 text-red-600 font-bold bg-gray-50">{item.away_odds.toFixed(2)}</td>
                                            <td className="py-3 px-4 text-gray-800 font-medium text-left truncate">
                                                {item.team_away}
                                            </td>
                                        </tr>
                                    ))
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            </main>
        </div>
    );
}
